<img src="https://capsule-render.vercel.app/api?type=waving&color=0:87CEEB,100:87CEEB&height=180&section=header&text=SUBZERO%20WHATSAPP%20BOT&fontSize=38&fontColor=ffffff&fontFamily=Roboto&animation=twinkling" width="100%"/>



<p align="center">
  <h1 align="center">❄️ SUBZERO-MD ❄️</h1>
</p>

  <p align="center">
<a href="https://github.com/mrfrank-ofc/followers"><img title="Followers" src="https://img.shields.io/github/followers/mrfrank-ofc?color=blue&style=flat-square"></a>
<a href="https://github.com/mrfrank-ofc/SUBZERO-BOT/stargazers/"><img title="Stars" src="https://img.shields.io/github/stars/mrfrank-ofc/SUBZERO-BOT?color=blue&style=flat-square"></a>
<a href="https://github.com/mrfrank-ofc/SUBZERO-BOT/network/members"><img title="Forks" src="https://img.shields.io/github/forks/mrfrank-ofc/SUBZERO-BOT?color=blue&style=flat-square"></a>
<a href="https://github.com/mrfrank-ofc/SUBZERO-BOT/"><img title="Size" src="https://img.shields.io/github/repo-size/mrfrank-ofc/SUBZERO-BOT?style=flat-square&color=green"></a>
<a href="https://github.com/mrfrank-ofc/SUBZERO-BOT/graphs/commit-activity"><img height="20" src="https://img.shields.io/badge/Maintained%3F-yes-green.svg"></a>&nbsp;&nbsp;
</p>
<p align='center'>
</p>

> **Current Bot Version ➜ `2.0.0 ⚡`**
---

```
Dont forget to fork 🍴 & star 🌟 repo😇
```
---

<p align="center">
  <a href="https://github.com/mrfrank-ofc">
    <img src="http://readme-typing-svg.herokuapp.com?color=blue&center=true&vCenter=true&multiline=false&lines=SUBZERO-MD-+MultiDevice;Developed+by+Mr+Frank;Give+star+and+fork+this+Repo+bro+🌟" alt="mrfrankReadme">
  </a>
</p>

--- 

<a><img src='https://i.imgur.com/wQOgFCH.jpeg'/></a>

<a><img src='https://i.imgur.com/LyHic3i.gif'/></a>

***

<p align="center">
  <a href="https://github.com/mrfrank-ofc"><img title="Developer" src="https://img.shields.io/badge/Author-Mr%20Frank-397604.svg?style=for-the-badge&logo=github" /></a>
</p>

<div align="center">
  
[![WhatsApp Channel](https://img.shields.io/badge/Join-WhatsApp%20Channel-FF00F8?style=for-the-badge&logo=whatsapp)](https://whatsapp.com/channel/0029VagQEmB002T7MWo3Sj1D)
</div>

 <p align="center"><img src="https://profile-counter.glitch.me/{SUBZERO-BOT}/count.svg" alt="mrfrank-ofc :: Visitor's Count" old_src="https://profile-counter.glitch.me/{mrfrank-ofc}/count.svg" /></p>


<p align="center">
<a href="https://github.com/mrfrank-ofc/SUBZERO-BOT"><img title="PUBLIC-BOT" src="https://img.shields.io/static/v1?label=Language&message=English&style=flat-square&color=darkpink"></a> &nbsp;
  <img src="https://komarev.com/ghpvc/?username=SUBZERO-BOT&label=VIEWS&style=flat-square&color=blue" />
</p>
</p> 

<p align="center">
  <a href="https://github.com/mrfrank-ofc/SUBZERO-BOT"><img title="Release" src="https://img.shields.io/badge/Release-beta%20v2.0-darkcyan.svg?style=for-the-badge&logo=appveyor" /></a>
</p>


***

### 1. Fork This Repository

Start by forking this repository to your own GitHub account. Click the button below to fork:

  <a href="https://github.com/mrfrank-ofc/SUBZERO-BOT/fork"><img title="SUBZERO-MD" src="https://img.shields.io/badge/FORK-SUBZERO-BOTh?color=blue&style=for-the-badge&logo=stackshare"></a>
  
### 2. Get Session ID 

You will need a session ID to run the SUBZERO-MD. Click the button below to obtain your session ID.if any error in loading site try vpn:

> **1️⃣Pair Code (Session ID)**

<a href='https://tinyurl.com/subzero-md' target="_blank">
  <img alt='Pairing Code' src='https://img.shields.io/badge/Get%20Pairing%20Code-orange?style=for-the-badge&logo=opencv&logoColor=black'/>
</a>
<br> 

> **2️⃣Pair Code (Session ID)**

<a href='https://subzero-md-pair5.onrender.com/' target="_blank">
  <img alt='Pairing Code' src='https://img.shields.io/badge/Get%20Pairing%20Code-darkpink?style=for-the-badge&logo=opencv&logoColor=black'/>
</a>
<br> 



---

<h2 align="center">SubZero Deployment Options</h2>

---

<h4 align="center">1. Heroku</h4>
<p style="text-align: center; font-size: 1.2em;">


<p align="center">
<a href='https://dashboard.heroku.com/new?template=https://github.com/mrfrank-ofc/SUBZERO-BOT/tree/main' target="_blank"><img alt='Heroku' src='https://img.shields.io/badge/-heroku ‎ deploy-FF004D?style=for-the-badge&logo=heroku&logoColor=white'/< width=150 height=28/p></a>

----------

<h4 align="center">2. TalkDrove Free</h4>
<p style="text-align: center; font-size: 1.2em;">
  
<p align="center">
<a href='https://talkdrove.com/share-bot/66' target="_blank"><img alt='Heroku' src='https://img.shields.io/badge/-TalkDrove ‎Deploy-6971FF?style=for-the-badge&logo=Github&logoColor=white'/< width=150 height=28/p></a>
  
<details>
  
<b><strong><summary align="center" style="color: Yello;">EASIEST METHOD</summary></strong></b>
<p style="text-align: center; font-size: 1.2em;">
 

<h3 align="center"> HOW TO DEPLOY ON TALKDROVE</h3>
<h6 align-"center">
Create Account Here:

https://host.talkdrove.com/auth/signup?ref=9535F15A

Then Login
Claim 10 coins in wallet section
Locate where to deploy your bot
You will see a dashboard of bots listed 


Click next , next
Until you see SUBZERO MD
Then click on it

You will be asked to fill in some stuffs like your session Id , and other stuffs on how you want your bot to be ( bot settings ) , it's not hard I added examples


Get session I'd here:

https://tinyurl.com/subzero-md

After you're done filling it
Click deploy button 

If you can't see any deploy button , switch the website to dark mode 

It will show

That's all bot connected

`MR FRANK OFC`</h6>
</details>

--------------


<h4 align="center">3. Koyeb</h4>
<p style="text-align: center; font-size: 1.2em;">


<p align="center">
<a href='https://app.koyeb.com/services/deploy?type=git&repository=mrfrank-ofc/SUBZERO-BOT&ports=3000&env[PREFIX]=.&env[SESSION_ID]=&env[ALWAYS_ONLINE]=false&env[MODE]=public&env[AUTO_STATUS_MSG]=Seen%20status%20by%20SUBZERO-MD&env[AUTO_STATUS_REPLY]=false&env[AUTO_STATUS_SEEN]=true&env[AUTO_TYPING]=false&env[ANTI_LINK]=true&env[AUTO_REACT]=false&env[READ_MESSAGE]=false' target="_blank"><img alt='Heroku' src='https://img.shields.io/badge/-koyeb ‎ deploy-FF009D?style=for-the-badge&logo=koyeb&logoColor=white'/< width=150 height=28/p></a>

-----
<h4 align="center">4. Railway</h4>
<p style="text-align: center; font-size: 1.2em;">

<p align="center">
<a href='https://railway.app/new' target="_blank"><img alt='Heroku' src='https://img.shields.io/badge/-railway deploy-FF8700?style=for-the-badge&logo=railway&logoColor=white'/< width=150 height=28/p></a>

-----

<h4 align="center">5. Render</h4>
<p style="text-align: center; font-size: 1.2em;">
  
<p align="center">
<a href='https://dashboard.render.com/web/new' target="_blank"><img alt='Heroku' src='https://img.shields.io/badge/-Render deploy-black?style=for-the-badge&logo=render&logoColot=white'/< width=150 height=28/p></a>
--------

<h4 align="center">6. Hugging Face</h4>
<p style="text-align: center; font-size: 1.2em;">
  
<p align="center">
<a href='https://app.netlify.com/' target="_blank"><img alt='Netlify' src='https://img.shields.io/badge/-Netlify Deploy-CC00FF?style=for-the-badge&logo=huggingface&logoColor=white'/< width=150 height=28/p></a> </a>

<details>
  
<b><strong><summary align="center" style="color: Yello;">EASIEST METHOD 2</summary></strong></b>
<p style="text-align: center; font-size: 1.2em;">
 

<h3 align="center"> HOW TO DEPLOY ON HUGGING FACE</h3>
<h6 align-"center">
*❄️ Deploy SubZero On Hugging Face For Free !*

`Specs :`
- v2 CPU
- 16GB RAM

> `Steps to deploy`

`Step 1`
1. Go to hugginface.co/join and create an account and verify your email too.

`Step 2`
1. Go to https://huggingface.co/spaces/mrfrank-ofc/SUBZERO-MD

2. Tap on *three dots* _(as shown in image)_

3. Tap on *duplicate space* _(as shown in image)_

`Step 3`
1. Fill your details, e.g., Session ID, Bot Name, owner number etc...

2. Tap on *duplicate space shown below*

```After that wait 10 seconds & your have deployed it successfuly  for free 24/7```

> CREDITS PIKABOTZ🎐

*ᴘᴏᴡᴇʀᴇᴅ ʙʏ ᴍʀ ꜰʀᴀɴᴋ ᴏꜰᴄ*</h6>

</details>

--------------


<h4 align="center">7. Replit</h4>
<p style="text-align: center; font-size: 1.2em;">

<p align="center">
<a href='https://replit.com/~' target="_blank"><img alt='Replit' src='https://img.shields.io/badge/-Replit Deploy-1976D2?style=for-the-badge&logo=replit&logoColor=white'/< width=150 height=28/p></a> </a>

 --------
 <h4 align="center">8. Workflow</h4>
<p style="text-align: center; font-size: 1.2em;">


<details>

<b><strong><summary align="center" style="color: Yello;">Deploy On Workflow</summary></strong></b>
<p style="text-align: center; font-size: 1.2em;">
 
<h8>Copy the workflow codes and then frok the repo edit config add session id then save and now click on repo action tag then click on start new workflow then paste workflow codes name them deploy and save the file</h8>
<h3 align-"center"> Important</h3>
<h6 align-"center">Attention! We do not take responsibility if your github account is suspended through this Deploy method, I advise you not to use this workflow deploy method in the latest github accounts, github accounts created a year or more ago have not received the risk of suspension so far, this works It will only be done for 6 hours, you need to update the code to reactivate it.</h6>

```
name: Node.js CI

on:
  push:
    branches:
      - main
  pull_request:
    branches:
      - main

jobs:
  build:

    runs-on: ubuntu-latest

    strategy:
      matrix:
        node-version: [20.x]

    steps:
    - name: Checkout repository
      uses: actions/checkout@v3

    - name: Set up Node.js
      uses: actions/setup-node@v3
      with:
        node-version: ${{ matrix.node-version }}

    - name: Install dependencies
      run: npm install

    - name: Start application
      run: npm start
```
</details> 

***




## 🌐 WhatsApp Channel 

Stay connected with the latest updates and community by joining our official WhatsApp group and channel. You can also contact the owner directly.

[![WhatsApp Channel](https://img.shields.io/badge/Join-WhatsApp%20Channel-25D366?style=for-the-badge&logo=whatsapp)](https://whatsapp.com/channel/0029VagQEmB002T7MWo3Sj1D)

***

<h2 align="left">⚠️ Reminder ⚠️</h2>
<p style="text-align: center; font-size: 1.2em;">

- **Disclaimer:** This bot is not affiliated with `WhatsApp Inc.`. Use it at your own risk.
- Misusing the bot may result in your `WhatsApp` account being banned. Note that you can only unban your account once.
- I am not responsible for any bans or misuse of the bot. Please keep this warning in mind before proceeding.

---

<h2 align="left">ℹ️ Notice</h2>
<p style="text-align: center; font-size: 1.2em;">
  Not For Sale - If any plugin's code is obfuscated, you do not have permission to edit it in any form. Please remember to give credit if you are using or re-uploading my plugins/files. Wishing you a wonderful day ahead!</p>
  
---

<h2 align="center"> Project Owners </h2>

---

### Thank You Dear

> DEVELOPER OF SUBZERO-MD 
- [Mr Frank ](https://github.com/mrfrank-ofc)
- Creater and Owner Of SUBZERO-MD

> SUBZERO-MD Helper
- [Frank](https://github.com/efkidgamerdev)
- For helping in bot plugin files.
---

 <br>
<h2 align="center"> ⚠️ Disclaimer ⚠️
 </h2>
 
 ---

<h3 align="center"> Don't Copy Without Permission 
</h3>

<br>

```
Thank you Pikachu, KHAN, SILENT SOBX, KERM & you supporters
```
-----
<a><img src='https://i.imgur.com/LyHic3i.gif'/></a>

------
