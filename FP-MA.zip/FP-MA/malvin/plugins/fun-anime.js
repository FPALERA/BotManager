function hi() {
  console.log("Hello World!");
}
hi();