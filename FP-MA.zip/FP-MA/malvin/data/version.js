
{
  "version": "2.0.1",
  "changelog": "📌 Added Update command, plugin count, and command count.\n🛠 Improved system info.\n🚀 Enhanced update detection."
}
